var decimal = Number(prompt("Input a number"));
alert(decimal.toString(16).toUpperCase());