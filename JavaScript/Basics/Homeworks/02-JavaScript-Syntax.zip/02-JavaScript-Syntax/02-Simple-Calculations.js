function roundNumber(number){
	var flooredNumber = Math.floor(number);
	var roundedNumber = Math.round(number);
	console.log(flooredNumber);
	console.log(roundedNumber);
}

console.log(roundNumber(22.7));
console.log(roundNumber(12.3));
console.log(roundNumber(58.7));