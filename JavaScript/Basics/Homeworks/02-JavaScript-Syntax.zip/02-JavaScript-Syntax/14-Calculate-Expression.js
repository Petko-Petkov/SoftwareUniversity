function calculate () {
	var result = eval(document.getElementById('input').value);
	document.getElementById('output').innerHTML = result;
}