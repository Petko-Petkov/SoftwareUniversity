function evenNumber(number){
	return number%2 !== 1;
}

console.log(evenNumber(3));
console.log(evenNumber(127));
console.log(evenNumber(588));

