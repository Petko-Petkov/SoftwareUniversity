﻿namespace Infestation
{
    public class HealthCatalyst : BaseSupplement
    {
        public HealthCatalyst()
            : base(healthEffect: 3)
        {
        }
    }
}
