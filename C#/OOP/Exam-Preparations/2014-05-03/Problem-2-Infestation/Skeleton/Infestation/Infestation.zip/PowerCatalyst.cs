﻿namespace Infestation
{
    public class PowerCatalyst : BaseSupplement
    {
        public PowerCatalyst()
            : base(powerEffect: 3)
        { 
        }
    }
}
