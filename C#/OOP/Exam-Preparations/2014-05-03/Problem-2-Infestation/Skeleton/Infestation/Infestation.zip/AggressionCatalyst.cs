﻿namespace Infestation
{
    public class AggressionCatalyst : BaseSupplement
    {
        public AggressionCatalyst()
            : base(aggressionAffect: 3)
        {
        }
    }
}
