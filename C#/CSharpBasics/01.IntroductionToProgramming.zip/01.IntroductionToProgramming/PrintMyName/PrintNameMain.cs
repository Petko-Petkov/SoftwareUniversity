﻿/*Modify the previous application to print your name. 
 * Ensure you have named the application well (e.g. “PrintMyName”).*/

namespace PrintMyName
{
    using System;

    class PrintNameMain
    {
        static void Main()
        {
            string name = "Petko Petkov";

            Console.WriteLine(name);
        }
    }
}
