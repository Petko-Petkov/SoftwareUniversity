﻿/*Create console application that prints your
 * first and last name, each at a separate line.*/ 

namespace PrinMyFullName
{
    using System;

    class PrintFullNameMain
    {
        static void Main()
        {
            string firstName = "Petko";
            string lastName = "Petkov";

            Console.WriteLine(firstName + " " + lastName);
        }
    }
}
